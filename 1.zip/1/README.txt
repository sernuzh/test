--------------UPLOAD IMAGES ON OPENCART 2.3.0.2 by Serhiy Nuzhnyy-----------------
index.php?route=checkout/upload - path to the front controller
orirginal images will be stored in folders : image/data, image/cache/data

							INSTALLATION
-copy files from the archive to their folders

-in the phpmyadmin table <product> change lenght of model field to 255 chars+++
-in admin panel Currencies-Default currency - remove symbols left and right+++
-in admin panel System-Settings-Edit-ImageUpload - set custom settings
-in admin remove one category from header menu to avoid overfloating to the low




